Student 1: Omer Aharoni, id:203865605

Student 2: Shay Ashkenazi, id: 208432799

//Comments:
- As premitted by lecturer, names in the project are defined one word only [no white spaces between names].
- IDs for counties and parties start from 1.
- Enter 1 for unified County or 2 for Divided County
- Enter 1 for regular election or 2 for simple election 


